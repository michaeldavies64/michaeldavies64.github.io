# Step 2: figures for the portfolio write-up, saved to images/
# Run from the project root: Rscript scr/02_portfolio_figures.R
suppressPackageStartupMessages({
  library(dplyr)
  library(ggplot2)
})
for (f in list.files("utils", pattern = "\\.R$", full.names = TRUE)) source(f, encoding = "UTF-8")

gps <- read_gps()
cap <- flag_capability_tests(read_capability())
save_fig <- function(plot, file, w = 8, h = 3.6) {
  ggsave(file.path("images", file), plot, width = w, height = h, dpi = 200, device = ragg::agg_png, bg = md_colours$surface)
}

# 1. Fixture timeline with head-coach eras ------------------------------------------
matches <- gps |>
  mutate(european = european_matches(gps)) |>
  filter(md_plus_code == 0) |>
  mutate(coach = coach_on(date))
data_span <- range(gps$date)
eras <- head_coaches |>
  mutate(start = pmax(start, data_span[1]), end = pmin(end, data_span[2])) |>
  filter(start <= end, label != "Saltor") |>
  mutate(
    shade = row_number() %% 2 == 0,
    mid = start + (end - start) / 2,
    text_x = if_else(label == "Tuchel", start + 3, mid),
    hjust = if_else(label == "Tuchel", 0, 0.5),
    n_matches = mapply(function(s, e) sum(matches$date >= s & matches$date <= e), start, end),
    label = ifelse(label == "Lampard", "Lampard*", label),
    label = paste0(label, "\n", n_matches, " matches")
  )
n_euro <- sum(matches$european)

p_fix <- ggplot() +
  geom_rect(data = eras, aes(xmin = start, xmax = end, ymin = -Inf, ymax = Inf, fill = shade), alpha = 1) +
  scale_fill_manual(values = c(`FALSE` = md_colours$surface, `TRUE` = md_colours$surface_raised), guide = "none") +
  geom_segment(data = filter(matches, !european), aes(x = date, xend = date, y = 0, yend = 1), colour = md_colours$context, linewidth = 0.7) +
  geom_segment(data = filter(matches, european), aes(x = date, xend = date, y = 0, yend = 1), colour = md_colours$signal, linewidth = 0.9) +
  geom_text(data = eras, aes(x = text_x, y = 1.32, label = label, hjust = hjust), size = 3, lineheight = 0.95,
            colour = md_colours$ink_secondary, family = "Inter") +
  scale_x_date(date_labels = "%b %Y", date_breaks = "6 months", expand = expansion(mult = 0.005)) +
  scale_y_continuous(limits = c(0, 1.55), expand = expansion(0)) +
  labs(
    title = paste0(nrow(matches), " matches under five head coaches, with ", n_euro, " European nights"),
    subtitle = "Every match day in the data. Teal: Champions League (2022/23) and Conference League (2024/25)",
    x = NULL, y = NULL,
    caption = "*Bruno Saltor took charge of one match as caretaker (4 April 2023) before Frank Lampard's appointment.\nFixture dates follow Chelsea's real calendar; the physical data is simulated."
  ) +
  theme_md(base_size = 11) +
  theme(axis.text.y = element_blank(), panel.grid.major.y = element_blank(), axis.line.x = element_line(colour = md_colours$baseline))
save_fig(p_fix, "fixtures_timeline.png", h = 3)
save_fig(p_fix + labs(caption = NULL, subtitle = NULL), "thumbnail.png", w = 8, h = 4.5)

# 2. Capability rows carried forward ------------------------------------------------
mv <- cap |> filter(movement == "sprint", quality == "max velocity", expression == "dynamic", !is.na(benchmark_pct))
p_cap <- ggplot(mv, aes(test_date, benchmark_pct)) +
  geom_step(colour = md_colours$context, linewidth = 0.6) +
  geom_point(data = filter(mv, is_new_result), colour = md_colours$signal, size = 1.6) +
  geom_hline(yintercept = 0.65, linetype = "dashed", colour = md_colours$baseline, linewidth = 0.4) +
  annotate("text", x = as.Date("2024-01-20"), y = 0.653, label = "Priority target: 65%", hjust = 0, vjust = 0,
           size = 3.1, colour = md_colours$ink_muted, family = "Inter") +
  scale_y_continuous(labels = scales::percent) +
  scale_x_date(date_labels = "%b %Y", date_breaks = "6 months") +
  labs(
    title = paste0("Only ", sum(mv$is_new_result), " of ", nrow(mv), " daily max velocity scores are new results"),
    subtitle = "Sprint max velocity (dynamic) benchmark score. Grey: daily rows. Teal: days a new result appears",
    x = NULL, y = NULL, caption = "Source: CFC Insights Vizathon 2025 (simulated data)"
  ) +
  theme_md(base_size = 11)
save_fig(p_cap, "capability_repeats.png")

message("Saved figures to images/")

# 3. Recovery coverage by category ---------------------------------------------------
rec <- read_recovery()
comp <- rec |>
  filter(category != "total", grepl("composite$", metric)) |>
  group_by(category) |>
  summarise(share = mean(!is.na(value)), .groups = "drop") |>
  bind_rows(
    rec |> filter(metric == "emboss_baseline_score") |> summarise(share = mean(!is.na(value))) |> mutate(category = "total")
  ) |>
  mutate(
    label = recode(category, bio = "Blood markers", msk_joint_range = "Joint range", msk_load_tolerance = "Load tolerance",
                   sleep = "Sleep", soreness = "Soreness", subjective = "Subjective wellness", total = "Overall score"),
    label = reorder(label, share),
    focus = category == "total"
  )
p_rec <- ggplot(comp, aes(share, label, fill = focus)) +
  geom_col(width = 0.6) +
  geom_text(aes(label = scales::percent(share, accuracy = 1)), hjust = -0.15, size = 3.3, colour = md_colours$ink_secondary, family = "Inter") +
  scale_fill_manual(values = c(`FALSE` = md_colours$context, `TRUE` = md_colours$signal), guide = "none") +
  scale_x_continuous(labels = scales::percent, limits = c(0, 0.72), expand = expansion(mult = c(0, 0.02))) +
  labs(
    title = paste0("The overall recovery score exists on ", scales::percent(comp$share[comp$focus], accuracy = 1), " of days, blood markers on ", scales::percent(min(comp$share), accuracy = 1)),
    subtitle = "Share of days with a recovery score, by category, July 2023 to March 2025",
    x = NULL, y = NULL, caption = "Source: CFC Insights Vizathon 2025 (simulated data)"
  ) +
  theme_md(base_size = 11) +
  theme(panel.grid.major.y = element_blank(), panel.grid.major.x = element_line(colour = md_colours$gridline, linewidth = 0.4),
        axis.text.y = element_text(colour = md_colours$ink_secondary, size = 10))
save_fig(p_rec, "recovery_coverage.png", h = 3.4)

# Numbers quoted in the write-up
overlap <- c(max(min(gps$date), min(rec$date)), min(max(gps$date), max(rec$date)))
in_window <- gps |> filter(date >= overlap[1], date <= overlap[2])
message("Sessions with recovery data alongside: ", sum(in_window$distance > 0), " (", format(overlap[1]), " to ", format(overlap[2]), ")")
