# Step 1: download the raw Vizathon files into input/
# Run from the project root: Rscript scr/01_download_data.R
source("utils/download_data.R")
files <- download_vizathon_data(dest = "input")
message("Downloaded ", length(files), " files to input/")
