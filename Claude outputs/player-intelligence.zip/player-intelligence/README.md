# Player intelligence system

A self-serve view of one player's training and match load, and how their recovery responds to it, built in R on the CFC Insights Vizathon 2025 data (simulated data for one player). Two modules: load demand, and load and recovery.

## Status

| Chapter | Status |
|---|---|
| 1. Data audit | Done: `docs/data_audit.html` |
| 2. Pipeline: DuckDB, `targets`, tests | Next |
| 3. Analysis: load norms, recovery response to load | Planned |
| 4. Shiny app: load demand, and load and recovery | Planned |

## Run it

From the project root, in R 4.1 or later:

```r
source("scr/01_download_data.R")        # fetches the four raw files into input/
quarto::quarto_render("docs/data_audit.qmd")
```

or in a terminal: `Rscript scr/01_download_data.R` then `quarto render docs/data_audit.qmd`.

Packages: `dplyr`, `tidyr`, `readr`, `lubridate`, `ggplot2`, `scales`, `knitr`, `ragg`. The report uses the Inter font if it is installed.

## Structure

```
├── app/          Shiny app (chapter 4)
├── code/         Pipeline steps built from utils functions (chapter 2)
├── data/         Cleaned data produced by the pipeline
├── docs/         Reports: data_audit.qmd and its rendered HTML
├── images/       Figures for the write-up
├── input/        Raw Vizathon files, downloaded, never committed
├── models/       Not used in this scope
├── output/       Generated reports and exports
├── queries/      SQL for the DuckDB layer (chapter 2)
├── rsconnect/    Deployment records
├── scr/          Run scripts, in order
└── utils/        Functions: download, readers, audit checks, ggplot theme
```

## Data

CFC Insights Vizathon 2025, Chelsea FC Performance Insights. The raw files are downloaded from the [public competition repository](https://github.com/Chelsea-Fc-Performance-Insights/Competition) and are not stored here.
