# Data-quality checks for the Vizathon files.
# Each audit_*() returns one row per check: what was tested, how many rows it affects, a status and a note.
# Status is one of "Pass", "Note" (worth knowing, no action needed) or "Issue" (needs handling in the pipeline).

check <- function(area, check, n, total, status, note) {
  tibble::tibble(area = area, check = check, n = n, total = total, status = status, note = note)
}

pass_if_zero <- function(n, fail = "Issue") if (n == 0) "Pass" else fail

# "7 March 2025": portable on Windows, macOS and Linux (unlike %-d)
fmt_day <- function(d, month = "%B") paste(as.integer(format(d, "%d")), format(d, paste(month, "%Y")))

audit_gps <- function(gps) {
  sessions <- dplyr::filter(gps, distance > 0)
  hr_min <- rowSums(dplyr::select(sessions, dplyr::starts_with("hr_zone_")))
  n_band <- sum(sessions$distance_over_24 > sessions$distance_over_21 | sessions$distance_over_27 > sessions$distance_over_24)
  n_acc <- sum(sessions$accel_decel_over_3_5 > sessions$accel_decel_over_2_5 | sessions$accel_decel_over_4_5 > sessions$accel_decel_over_3_5)
  n_zero <- sum(gps$distance == 0)
  n_zero_match <- sum(gps$distance == 0 & gps$md_plus_code == 0)
  n_hr <- sum(hr_min > sessions$day_duration * 1.1)
  n_frac <- sum(sessions$accel_decel_over_2_5 %% 1 != 0)
  gaps <- as.numeric(diff(gps$date))

  dplyr::bind_rows(
    check("GPS", "One row per date", sum(duplicated(gps$date)), nrow(gps), pass_if_zero(sum(duplicated(gps$date))), "Each date appears once, so date is a safe join key."),
    check("GPS", "Dates parse as day/month/year", sum(is.na(gps$date)), nrow(gps), pass_if_zero(sum(is.na(gps$date))), "All dates valid."),
    check("GPS", "Days with no session recorded", n_zero, nrow(gps), "Note", "Every calendar day has a row; days off are rows of zeros, not missing rows. Exclude them from averages."),
    check("GPS", "Match days with no data", n_zero_match, sum(gps$md_plus_code == 0), pass_if_zero(n_zero_match, "Note"), "All three fall in a 29-day block of zeros from 14 March 2025, which suggests a period of unavailability rather than errors."),
    check("GPS", "Speed bands are nested (>27 within >24 within >21 km/h)", n_band, nrow(sessions), pass_if_zero(n_band), "Higher-speed distance sometimes exceeds the band below it, which cannot happen if the bands are cumulative. Treat bands as approximate and avoid subtracting them to make zones."),
    check("GPS", "Acceleration bands are nested", n_acc, nrow(sessions), pass_if_zero(n_acc), "A handful of sessions have more efforts above 4.5 m/s\u00b2 than above 3.5 m/s\u00b2."),
    check("GPS", "Effort counts are whole numbers", n_frac, nrow(sessions), pass_if_zero(n_frac, "Note"), "Counts are fractional, a sign of simulation. Round for display only."),
    check("GPS", "Heart rate time fits within session duration", n_hr, nrow(sessions), pass_if_zero(n_hr, "Note"), "Time in HR zones exceeds session duration by more than 10% in a few sessions. HR may be recorded over a longer window."),
    check("GPS", "Continuous daily coverage in season", sum(gaps > 1), length(gaps), "Note", "Daily from 1 August to 31 May each season; June and July are absent, so there is no GPS pre-season data.")
  )
}

audit_capability <- function(cap) {
  cap <- flag_capability_tests(cap)
  n_dup <- sum(duplicated(dplyr::select(cap, test_date, movement, quality, expression)))
  n_carried <- sum(!is.na(cap$benchmark_pct) & !cap$is_new_result)
  n_na <- sum(is.na(cap$benchmark_pct))
  n_out <- sum(cap$benchmark_pct > 1 | cap$benchmark_pct < 0, na.rm = TRUE)

  dplyr::bind_rows(
    check("Capability", "One row per date and test combination", n_dup, nrow(cap), pass_if_zero(n_dup), "20 movement, quality and expression combinations every day."),
    check("Capability", "Rows that are carried forward, not new results", n_carried, nrow(cap), "Issue", "Values repeat until a new test, as the guide says. Use only new results for trends and test counts, or trends will look smoother and more frequent than they are."),
    check("Capability", "Missing benchmark scores", n_na, nrow(cap), "Note", "Missing where there is not yet enough data for a benchmark, mostly isometric tests early on."),
    check("Capability", "Scores outside 0\u2013100%", n_out, sum(!is.na(cap$benchmark_pct)), "Note", "Benchmark scores can exceed 100% or fall below 0, so they are relative scores rather than percentiles. Do not cap them.")
  )
}

audit_recovery <- function(rec) {
  n_dup <- sum(duplicated(dplyr::select(rec, date, metric)))
  wide <- rec |>
    dplyr::filter(category != "total") |>
    dplyr::mutate(
      domain = sub("_baseline_(completeness|composite)$", "", metric),
      kind = sub(".*_baseline_", "", metric)
    ) |>
    dplyr::select(date, domain, kind, value) |>
    tidyr::pivot_wider(names_from = kind, values_from = value)
  n_incons <- sum((wide$completeness == 0) != is.na(wide$composite), na.rm = TRUE)
  total <- dplyr::filter(rec, metric == "emboss_baseline_score")
  mean_comp <- wide |> dplyr::group_by(date) |> dplyr::summarise(mean_comp = mean(composite, na.rm = TRUE), .groups = "drop")
  cmp <- dplyr::inner_join(total, mean_comp, by = "date") |> dplyr::filter(!is.na(value), is.finite(mean_comp))
  n_differs <- sum(abs(cmp$value - cmp$mean_comp) > 0.01)

  dplyr::bind_rows(
    check("Recovery", "One row per date and metric", n_dup, nrow(rec), pass_if_zero(n_dup), "13 metrics every day: 6 categories with 2 metrics each, plus the overall score."),
    check("Recovery", "Completeness of 0 always means no composite score", n_incons, nrow(wide), pass_if_zero(n_incons), "Consistent: a composite exists only on days its tests were completed."),
    check("Recovery", "Days with an overall recovery score", sum(!is.na(total$value)), nrow(total), "Note", "The overall score exists on 60% of days. Missing means not collected, not zero."),
    check("Recovery", "Overall score equals the mean of the category composites", n_differs, nrow(cmp), "Note", "The overall score tracks the category mean but is not equal to it, so its weighting is unknown. Use it as supplied rather than recomputing it.")
  )
}

audit_priorities <- function(pri, cap, data_end) {
  latest_mv <- cap |>
    dplyr::filter(movement == "sprint", quality == "max velocity", expression == "dynamic", !is.na(benchmark_pct)) |>
    dplyr::slice_max(test_date, n = 1)
  dplyr::bind_rows(
    check("Priorities", "Review dates fall within the data", sum(pri$review_date > data_end), nrow(pri), "Note",
          sprintf("All three targets are reviewed on %s, after the capability and recovery data end on %s.", fmt_day(max(pri$review_date)), fmt_day(data_end))),
    check("Priorities", "Targets can be measured from the data", 2, nrow(pri), "Note",
          "Sleep is recorded as a relative quality score, not hours, and nutrition is not recorded at all. Only the sprint target maps to a measured score."),
    check("Priorities", "Sprint target status matches the data", as.integer(latest_mv$benchmark_pct <= 0.65), 1, if (latest_mv$benchmark_pct > 0.65) "Pass" else "Issue",
          sprintf("Marked “Achieved” (>65%% max velocity score), but the latest dynamic max velocity score is %.2f%% on %s.", 100 * latest_mv$benchmark_pct, fmt_day(latest_mv$test_date)))
  )
}
