# Real-world context for the Vizathon fixture list.
# The physical values in the data are simulated, but the match dates and opponents follow
# Chelsea's real calendar from August 2022 to April 2025. These tables add that context.
#
# Sources (checked October 2026):
#   Head coaches: Wikipedia, "History of Chelsea F.C. (2022–present)"; theScore (Tuchel sacked 7 Sep 2022);
#   Wikipedia, "Bruno Saltor" (caretaker for one match, 4 Apr 2023).
#   Seasons: The Analyst (12th, 2022/23); chelseafc.com "Chelsea in 2023/24" (6th, no Europe, League Cup final);
#   premierleague.com (4th, 2024/25); Sports Illustrated (Conference League final, 28 May 2025).

head_coaches <- tibble::tribble(
  ~coach,               ~label,          ~start,       ~end,
  "Thomas Tuchel",      "Tuchel",        "2022-07-01", "2022-09-07",
  "Graham Potter",      "Potter",        "2022-09-08", "2023-04-02",
  "Bruno Saltor",       "Saltor",        "2023-04-03", "2023-04-05",
  "Frank Lampard",      "Lampard",       "2023-04-06", "2023-06-30",
  "Mauricio Pochettino","Pochettino",    "2023-07-01", "2024-06-30",
  "Enzo Maresca",       "Maresca",       "2024-07-01", "2025-06-30"
) |>
  dplyr::mutate(dplyr::across(c(start, end), as.Date))

season_context <- tibble::tribble(
  ~season,     ~league_finish, ~europe,                                          ~note,
  "2022/2023", "12th",         "Champions League, quarter-finals",               "Three head coaches and a caretaker",
  "2023/2024", "6th",          "None",                                           "League Cup final; FA Cup semi-final",
  "2024/2025", "4th",          "Conference League (won the final in May 2025)",  "Data ends in April 2025, before the final"
)

# European opponents that appear in the data (pre-season friendlies excluded)
european_matches <- function(gps) {
  euro_2022 <- c("Dinamo Zagreb", "Salzburg", "Milan", "Borussia Dortmund", "Real Madrid")
  euro_2024 <- c("Servette", "Gent", "Panathinaikos", "Noah", "Heidenheim", "Astana", "Shamrock Rovers", "København")
  gps$md_plus_code == 0 & (
    (gps$season == "2022/2023" & gps$opposition_full %in% euro_2022) |
    (gps$season == "2024/2025" & gps$opposition_full %in% euro_2024)
  )
}

coach_on <- function(dates) {
  vapply(dates, function(d) {
    hit <- head_coaches$coach[d >= head_coaches$start & d <= head_coaches$end]
    if (length(hit)) hit else NA_character_
  }, character(1))
}
