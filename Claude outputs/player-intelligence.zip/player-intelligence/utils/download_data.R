# Downloads the CFC Insights Vizathon 2025 data from Chelsea's public repository.
# The raw files are not stored in this repository; run scr/01_download_data.R to fetch them.

vizathon_files <- c(
  gps        = "CFC GPS Data.csv",
  capability = "CFC Physical Capability Data_.csv",
  recovery   = "CFC Recovery status Data.csv",
  priorities = "CFC Individual Priority Areas.csv"
)

vizathon_base_url <- "https://raw.githubusercontent.com/Chelsea-Fc-Performance-Insights/Competition/main/DATA/"

download_vizathon_data <- function(dest = "input", overwrite = FALSE) {
  dir.create(dest, showWarnings = FALSE, recursive = TRUE)
  for (f in vizathon_files) {
    path <- file.path(dest, f)
    if (file.exists(path) && !overwrite) next
    url <- paste0(vizathon_base_url, utils::URLencode(f))
    utils::download.file(url, path, mode = "wb", quiet = TRUE)
  }
  invisible(file.path(dest, vizathon_files))
}
