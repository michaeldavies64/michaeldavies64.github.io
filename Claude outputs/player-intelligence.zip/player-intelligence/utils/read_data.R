# Readers for the four Vizathon files.
# Each returns a tibble with parsed dates, consistent column names and rows sorted by date.
# Known quirks handled here (see docs/data_audit.qmd):
#   - GPS file is Latin-1 encoded (opposition names such as "København")
#   - Capability file starts with a UTF-8 byte-order mark on the first column name
#   - All dates are day/month/year
#   - Capability and recovery files are not sorted by date

read_gps <- function(dir = "input") {
  readr::read_csv(
    file.path(dir, vizathon_files[["gps"]]),
    locale = readr::locale(encoding = "latin1"),
    show_col_types = FALSE
  ) |>
    dplyr::mutate(
      date = lubridate::dmy(date),
      dplyr::across(dplyr::starts_with("hr_zone_"), ~ as.numeric(.x) / 60, .names = "{sub('_hms', '_min', .col)}")
    ) |>
    dplyr::select(-dplyr::ends_with("_hms")) |>
    dplyr::arrange(date)
}

read_capability <- function(dir = "input") {
  readr::read_csv(file.path(dir, vizathon_files[["capability"]]), show_col_types = FALSE) |>
    dplyr::rename_with(~ sub("^﻿", "", .x)) |>
    dplyr::rename(test_date = testDate, benchmark_pct = benchmarkPct) |>
    dplyr::mutate(test_date = lubridate::dmy(test_date)) |>
    dplyr::arrange(movement, quality, expression, test_date)
}

read_recovery <- function(dir = "input") {
  readr::read_csv(file.path(dir, vizathon_files[["recovery"]]), show_col_types = FALSE) |>
    dplyr::rename(date = sessionDate, season = seasonName) |>
    dplyr::mutate(date = lubridate::dmy(date)) |>
    dplyr::arrange(date, category, metric)
}

read_priorities <- function(dir = "input") {
  readr::read_csv(file.path(dir, vizathon_files[["priorities"]]), show_col_types = FALSE) |>
    janitor_names() |>
    dplyr::mutate(dplyr::across(c(target_set, review_date), lubridate::dmy))
}

# Minimal snake_case for column names, to avoid a janitor dependency
janitor_names <- function(df) {
  names(df) <- tolower(gsub("[^A-Za-z0-9]+", "_", trimws(names(df))))
  df
}

# Marks capability rows that are genuine new results rather than values carried forward
flag_capability_tests <- function(cap) {
  cap |>
    dplyr::group_by(movement, quality, expression) |>
    dplyr::mutate(
      is_new_result = !is.na(benchmark_pct) &
        (is.na(dplyr::lag(benchmark_pct)) | benchmark_pct != dplyr::lag(benchmark_pct))
    ) |>
    dplyr::ungroup()
}
